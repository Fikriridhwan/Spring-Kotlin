package com.virtualpairprogrammers.learningkotlin.kotlin

fun main(args: Array<String>) {

    var name: String? = null

    //name = "Matt"

    println(name!!.toUpperCase())

    var address :String? = null

    address = "Hello"

    var myInteger :Int? = 7

    myInteger = null
}