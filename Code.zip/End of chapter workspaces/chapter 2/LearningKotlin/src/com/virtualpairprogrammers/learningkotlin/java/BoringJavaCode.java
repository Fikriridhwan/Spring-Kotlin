package com.virtualpairprogrammers.learningkotlin.java;

public class BoringJavaCode {

    public static void main(String args[]) {
        String name = "Matt";
    }

}
